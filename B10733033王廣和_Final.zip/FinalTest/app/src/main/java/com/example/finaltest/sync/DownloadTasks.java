package com.example.finaltest.sync;

import android.content.Context;

import com.example.finaltest.utilities.NetworkUtils;

public class DownloadTasks {
    //為action命名
    public static final String ACTION_LEFT = "LEFT";
    public static final String ACTION_RIGHT = "RIGHT";
    public static String direction = "left";

    public static void executeTask(Context context, String action) {
    //判斷進來的action要採取甚麼動作
        if(ACTION_RIGHT.equals(action)){
            direction = "right";
            getRight(context,direction);

        }else if(ACTION_LEFT.equals(action)){
            direction = "left";
            getLeft(context,direction);
        }else{

        }
    }

    private static void getLeft(Context context,String direction) {
        NetworkUtils.getData(context,direction);
    }

    private static void getRight(Context context,String direction) {
        NetworkUtils.getData(context,direction);
    }
}
