package com.example.finaltest.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferenceUtilities {
    public static  final String KEY_RIGHT_VALUE ="right-value";
    public static  final String KEY_RIGHT_COUNT = "right-count";
    public static  final String KEY_LEFT_VALUE = "left-value";
    public static  final String KEY_LEFT_COUNT="left-count";

    public static  final String DEFAULT_CONTENT="default-content";
    public static String getData(Context context,String direction) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String content = "";
        if(direction.equals("left")){
            content= prefs.getString(KEY_LEFT_VALUE,DEFAULT_CONTENT);
        }else if (direction.equals("right")){
            content= prefs.getString(KEY_RIGHT_VALUE,DEFAULT_CONTENT);
        }
        return content;
    }

    public static void setData(Context context,String content,String direction) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        if (direction.equals("left")){
            editor.putString(KEY_LEFT_VALUE,content);
        }else if (direction.equals("right")){
            editor.putString(KEY_RIGHT_VALUE,content);
        }
        editor.apply();
    }
}
