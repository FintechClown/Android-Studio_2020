package com.example.finaltest.sync;

import android.content.Context;

import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.Trigger;

public class DownloadUtilities {
    private static final int DOWNLOAD_INTERVAL_SECONDS = 30;
    private static final int SYNC_FLEXTIME_SECONDS = DOWNLOAD_INTERVAL_SECONDS;
    private static final String DOWNLOAD_JOB_TAG = "download_reminder_tag";
    private static boolean sInitialized = false;

    synchronized public static void scheduleDownload (final Context context){
        if (sInitialized = true){return;}
        GooglePlayDriver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);
        Job job = dispatcher.newJobBuilder()
                .setService(DownloadFirebaseJobService.class)
                .setTag(DOWNLOAD_JOB_TAG)
                .setConstraints(Constraint.DEVICE_CHARGING)
                .setLifetime(Lifetime.FOREVER)
                .setRecurring(true)
                .setTrigger(Trigger.executionWindow(DOWNLOAD_INTERVAL_SECONDS,DOWNLOAD_INTERVAL_SECONDS+SYNC_FLEXTIME_SECONDS))
                .setReplaceCurrent(true)
                .build();
        dispatcher.schedule(job);
        sInitialized = true;
    }
}
