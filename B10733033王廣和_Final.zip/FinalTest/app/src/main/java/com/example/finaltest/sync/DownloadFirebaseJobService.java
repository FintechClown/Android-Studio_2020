package com.example.finaltest.sync;

import android.content.Context;
import android.os.AsyncTask;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

public class DownloadFirebaseJobService extends JobService {
    AsyncTask mBackgroundTask;
    @Override
    public boolean onStartJob(final JobParameters job) {
        mBackgroundTask = new AsyncTask() {
            @Override
            protected Object doInBackground(Object[] objects) {
                Context context = DownloadFirebaseJobService.this;
                DownloadTasks.executeTask(context,DownloadTasks.ACTION_LEFT);
                return null;
            }
            protected void onPostExecute(Object o){
                jobFinished(job,false);
            }
        };
        mBackgroundTask.execute();
        return true;
    }

    public boolean onStopJob(JobParameters job) {
        if(mBackgroundTask != null){
            mBackgroundTask.cancel(true);
        }
        return true;
    }
}
