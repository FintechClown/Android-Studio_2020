package com.example.finaltest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finaltest.sync.DownloadIntentService;
import com.example.finaltest.sync.DownloadTasks;
import com.example.finaltest.sync.DownloadUtilities;
import com.example.finaltest.utilities.NotificationUtils;
import com.example.finaltest.utilities.PreferenceUtilities;

import static com.example.finaltest.utilities.PreferenceUtilities.KEY_LEFT_VALUE;

public class MainActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {
    TextView tv_leftcount_value,tv_rightcount_value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_leftcount_value = (TextView)findViewById(R.id.tv_leftcount_value);
        tv_rightcount_value = (TextView)findViewById(R.id.tv_rightcount_value);
        //notification排程通知
        DownloadUtilities.scheduleDownload(this);

        //監聽sharedpref改變&設定初始textview
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String leftCount = prefs.getString(KEY_LEFT_VALUE," should not appear");
        //String rightCount = prefs.getString(KEY_RIGHT_VALUE," should not appear");
        tv_leftcount_value.setText(leftCount);
        prefs.registerOnSharedPreferenceChangeListener(this);

    }
    public void touched(){
        Intent intent = new Intent(this, DownloadIntentService.class);
        intent.setAction(DownloadTasks.ACTION_LEFT);
        startService(intent);
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void testNotification(View view){
        NotificationUtils.BuildUpNotification(this);
        touched();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.unregisterOnSharedPreferenceChangeListener(this);
    }
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (PreferenceUtilities.KEY_LEFT_COUNT.equals(key)) {
            updateLeftCount();
        } else if (PreferenceUtilities.KEY_RIGHT_COUNT.equals(key)) {
            updateRightCount();
        }
    }

    private void updateRightCount() {
        String rightCount = PreferenceUtilities.getData(this,"right");
        tv_rightcount_value.setText(rightCount+"");
    }

    private void updateLeftCount() {
        String leftCount = PreferenceUtilities.getData(this,"left");
        tv_leftcount_value.setText(leftCount+"");
    }
}
