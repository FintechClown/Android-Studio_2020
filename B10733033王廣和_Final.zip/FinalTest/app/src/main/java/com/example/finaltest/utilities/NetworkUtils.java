package com.example.finaltest.utilities;

import android.content.Context;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NetworkUtils {
    final static String LEFT_URL = "https://boiling-headland-50805.herokuapp.com/click/1";
    final static String Right_URL = "https://boiling-headland-50805.herokuapp.com/click/2";
    public static void getData(Context context,String direction) {
        Uri uri = null;
        if (direction.equals("left")){
            uri = Uri.parse(LEFT_URL).buildUpon().build();
        }else if (direction.equals("right")){
            uri = Uri.parse(Right_URL).buildUpon().build();
        }

        URL url = null;
        try {
            url = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        try {
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            InputStream in = urlConnection.getInputStream();
            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");
            String content = scanner.next();
            PreferenceUtilities.setData(context,content,direction);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
