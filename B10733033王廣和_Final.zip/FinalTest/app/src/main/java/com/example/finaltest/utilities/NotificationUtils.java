package com.example.finaltest.utilities;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.finaltest.MainActivity;
import com.example.finaltest.R;
import com.example.finaltest.sync.DownloadIntentService;
import com.example.finaltest.sync.DownloadTasks;

public class NotificationUtils {
    private static final int DOWNLOAD_PENDING_INTENT_ID = 1;
    private static final String DOWNLOAD_NOTIFICATION_CHANNEL_ID = "download_notification_channel";
    private static final int DOWNLOAD_NOTIFICATION_ID = 11;

    private static final int ACTION_LEFT_PENDING_INTENT_ID = 110;
    private static final int ACTION_RIGHT_PENDING_INTENT_ID = 111;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static void BuildUpNotification(Context context){
        //建立notitfication要做兩件事 建立channel跟內容
        NotificationManager notificationManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        //建立channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(
                    DOWNLOAD_NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.main_notification_channel_name),
                    NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(mChannel);
        }
        //建立內容
        NotificationCompat.Builder builder =new NotificationCompat.Builder(context,DOWNLOAD_NOTIFICATION_CHANNEL_ID)
                .setColor(ContextCompat.getColor(context,R.color.colorPrimary))
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(context.getString(R.string.download_notification_title))
                .setContentText(context.getText(R.string.download_notification_body))
                .setContentIntent(contentIntent(context))
                .addAction(LeftAction(context))
                .addAction(RightAction(context))
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                && Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }
        notificationManager.notify(DOWNLOAD_NOTIFICATION_ID, builder.build());
    }
    private static PendingIntent contentIntent(Context context){
        Intent intent =new Intent(context, MainActivity.class);
        return PendingIntent.getActivity(
                context,
                DOWNLOAD_PENDING_INTENT_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
        );
    }

    public static NotificationCompat.Action LeftAction(Context context){
        Intent intent = new Intent(context, DownloadIntentService.class);
        intent.setAction(DownloadTasks.ACTION_LEFT);
        PendingIntent pendingIntent =PendingIntent.getService(
                context,
                ACTION_LEFT_PENDING_INTENT_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Action action = new NotificationCompat.Action(R.drawable.ic_launcher_background,"LEFT",pendingIntent);
        return action;
    }

    public static NotificationCompat.Action RightAction(Context context){
        Intent intent = new Intent(context, DownloadIntentService.class);
        intent.setAction(DownloadTasks.ACTION_RIGHT);
        PendingIntent pendingIntent =PendingIntent.getService(
                context,
                ACTION_RIGHT_PENDING_INTENT_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Action action = new NotificationCompat.Action(R.drawable.ic_launcher_background,"RIGHT",pendingIntent);
        return action;
    }
}
