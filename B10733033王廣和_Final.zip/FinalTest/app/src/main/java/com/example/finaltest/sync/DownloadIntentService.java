package com.example.finaltest.sync;

import android.app.IntentService;
import android.content.Intent;

import androidx.annotation.Nullable;

public class DownloadIntentService extends IntentService {

    public DownloadIntentService() {
        super("DownloadIntentService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        String action = intent.getAction();
        DownloadTasks.executeTask(DownloadIntentService.this,action);
    }
}
