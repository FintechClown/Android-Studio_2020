package com.example.b10733033_hw01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView textView2;
    Button button2;
    Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView2 = (TextView) findViewById(R.id.textView2);
        button2 =(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);

        /*getIntent把資料拿進來*/
        Intent intent = getIntent();
        int data = intent.getIntExtra("Data",0);/*default value不知道是甚麼 我預設為0*/
        textView2.setText("共"+data+"個");

        /*其實也可以oncreate直接extend onclick listener 把事件用switch透過v.getID寫在一起*/
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intent2);
                /*   重新呼叫main activity 會變成A-->B-->A'   */
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                /*  直接finish掉second activity ，讓原本底下的main activity浮上來*/
            }
        });
    }
}
