package com.example.b10733033_hw01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import static androidx.recyclerview.widget.RecyclerView.*;

class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>{
    Context context;
    ArrayList<MainActivity.MyItem> myItems;
    int count = 0;
    Adapter(Context context, ArrayList<MainActivity.MyItem> myItems){
        this.context = context;
        this.myItems = myItems;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.view,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        viewHolder.textView = (TextView)view.findViewById(R.id.textView);
        viewHolder.checkBox = (CheckBox)view.findViewById(R.id.checkBox);
        return viewHolder;
        /*Create 這裡有點類似要畫出每個RecyclerView裡面item的藍圖
                *用LayoutInflater把item.xml連接過來
                *再建立holder 並把剛剛串起來的view丟進去
                *把view裡面item的東西連到這裡，告訴holder你的item view大概長甚麼樣子
                */
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        /*  把資料跟item view串起來*/
        final MainActivity.MyItem Myitem = myItems.get(position);
        holder.textView.setText(Myitem.str);
        holder.checkBox.setChecked(Myitem.b);
        holder.checkBox.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.checkBox.isChecked()){
                    myItems.get(position).b = true;
                    count++;
                }else{
                    myItems.get(position).b = false;
                    count--;
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return myItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        CheckBox checkBox;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
