package com.example.b10733033_hw01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btn;
    RecyclerView recyclerView;
    ArrayList<MyItem> myItems = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*圖形元件*/
        recyclerView= (RecyclerView)findViewById(R.id.recyclerview);
        Button btn = (Button)findViewById(R.id.button);
        /*  塞點自訂義data   */
        for(int i = 0 ;i<50;i++){
            myItems.add(new MyItem("我是第"+i+"個啦",false));
        }
        /*建立Adapter*/
        final Adapter adapter = new Adapter(this,myItems);
        /*recyclerview要建立layout manager，把context塞進去*/
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        /*把剛剛的adapter物件塞進去recyclerview*/
        recyclerView.setAdapter(adapter);

        /*跳轉activity的按鈕*/
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*使用intent跳轉second activity，putExtra塞資料帶過去(也可使用bundle)*/
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                /*偷懶不寫get，讓count變成public直接取*/
                intent.putExtra("Data",adapter.count);
                startActivity(intent);
                /*建立intent要start，就跟toast set完要show一樣*/
            }
        });

    }

    class MyItem {
        /*自訂物件*/
        String str ;
        Boolean b;
        MyItem(String str,Boolean b){
            this.str = str;
            this.b = b;
        }
    }
}
